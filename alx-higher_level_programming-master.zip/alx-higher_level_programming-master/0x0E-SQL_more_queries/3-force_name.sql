-- creates the table force_name on mysql server
-- database name passed as an argument of the mysql command
CREATE TABLE IF NOT EXISTS force_name (id INT,
		name VARCHAR(256) NOT NULL
		);
