### JavaScript - Objects, Scopes and Closures
