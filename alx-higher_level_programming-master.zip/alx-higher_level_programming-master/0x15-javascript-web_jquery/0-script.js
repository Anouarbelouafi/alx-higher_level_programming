#!/usr/bin/node
/**
  * updates the color of the <header> element to red
  */
window.onload = function myFunction () {
  const elem = document.querySelector('header');
  elem.style.color = 'red';
};
