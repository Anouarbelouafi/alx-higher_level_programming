### Javascript - Warm up
