#!/usr/bin/node
const myLines = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
const arrayLength = myLines.length;
let i = 0;
while (i < arrayLength) {
  console.log(myLines[i]);
  i++;
}
