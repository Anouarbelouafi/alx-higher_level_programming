#!/usr/bin/python3
def number_keys(a_dictionary):
    count = 0
    for key, elem in enumerate(a_dictionary):
        count += 1
    return count
