### Python - Exceptions
