#!/usr/bin/python3
"""
no module imported
"""


class Square:
    """
    Empty class that defines a square
    """
    pass
