-- displays the number of recors with id = 89 in the table first_table
-- database name will be passed as an argument of mysql command
SELECT COUNT(*) FROM first_table WHERE id = 89;
