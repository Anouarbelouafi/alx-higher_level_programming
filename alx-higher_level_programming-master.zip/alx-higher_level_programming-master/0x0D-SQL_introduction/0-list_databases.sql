-- lists all the databases of my mysql server
-- query to list databases
SHOW DATABASES;
