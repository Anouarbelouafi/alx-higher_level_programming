-- creates a table called firt_table in the current database
-- database will be passed as argument of the mysql command
CREATE TABLE IF NOT EXISTS first_table (id INT,
		name VARCHAR(256)
		);
