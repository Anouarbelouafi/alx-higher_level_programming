-- lists all rows of the table first_table
-- all fields should be printed
SELECT * FROM first_table;
