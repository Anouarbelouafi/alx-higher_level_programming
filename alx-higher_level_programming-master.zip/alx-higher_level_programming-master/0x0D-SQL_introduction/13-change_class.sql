-- Removes all records with a score <= 5 in table second_table
-- database name passed as an argument of the mysql command
DELETE FROM second_table WHERE score <= 5;
