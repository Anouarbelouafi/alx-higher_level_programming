-- computes score average of all records in the table second_table
-- result column should be aveage
SELECT AVG(score) AS average FROM second_table;
