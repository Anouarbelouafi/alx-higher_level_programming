-- deletes the database hbtn_0c_0 in mysql server
-- script does not fail if database doesn't exist
DROP DATABASE IF EXISTS hbtn_0c_0
