-- inserts a new row in the table first_table
-- database name is passes as argument of the mysql command
INSERT INTO first_table (`id`, `name`) VALUES (89, "Holberton School");
