-- lists all records of the table second_table
-- display both score and name, and database is passed as an argument of the mysql command
SELECT score, name FROM second_table ORDER BY score DESC;
