### SQL - Introduction
![sql_image_meme](images/sql_img.jpg)
