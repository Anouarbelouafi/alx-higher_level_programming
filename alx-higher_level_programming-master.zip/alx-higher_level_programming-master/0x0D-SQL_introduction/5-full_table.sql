-- print full description of the table first_table
-- not allowed to use the decribe or explain statements
SHOW CREATE TABLE first_table;
