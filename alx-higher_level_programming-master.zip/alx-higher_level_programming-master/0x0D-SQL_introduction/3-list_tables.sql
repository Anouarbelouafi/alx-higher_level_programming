-- lists all the tables of a database in mysql server
-- database name will be passed as argument of mysql command
SHOW tables;
