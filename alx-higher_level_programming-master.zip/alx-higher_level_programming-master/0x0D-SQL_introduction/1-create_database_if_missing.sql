-- script that creates the database hbtn_0c_0 in your mysql server
-- should not fail if the database already exists
CREATE DATABASE IF NOT EXISTS hbtn_0c_0;
