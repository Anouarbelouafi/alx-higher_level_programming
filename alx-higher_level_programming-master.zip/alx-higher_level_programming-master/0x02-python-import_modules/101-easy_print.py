#!/usr/bin/python3
import my_print
