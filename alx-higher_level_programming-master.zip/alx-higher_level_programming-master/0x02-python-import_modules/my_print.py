#!/usr/bin/python3
print("#pythoniscool")