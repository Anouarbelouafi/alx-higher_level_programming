#!/usr/bin/python3
str = "Holberton School"
print(f"{str * 3}\n{str[:9]}")
