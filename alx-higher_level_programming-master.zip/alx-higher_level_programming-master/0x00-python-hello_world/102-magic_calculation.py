#!/usr/bin/python3
"""calculation"""


def magic_calculation(a, b):
    """does exactly same as bytecode given"""
    const = 98
    result = pow(a, b) + const
    return result
