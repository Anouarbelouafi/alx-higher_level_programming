def hello():
	print("I'm here")
hello()
