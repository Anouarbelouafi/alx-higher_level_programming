#!/usr/bin/python3
print("Best School")
