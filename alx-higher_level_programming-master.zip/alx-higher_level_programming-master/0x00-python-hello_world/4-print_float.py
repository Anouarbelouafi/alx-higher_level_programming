#!/usr/bin/python3
number = 3.14159
print("{} {:.2f}".format("Float:", number))
