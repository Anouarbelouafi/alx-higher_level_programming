#!/usr/bin/python3
"""empty class"""


class BaseGeometry:
    """empty"""
    pass
