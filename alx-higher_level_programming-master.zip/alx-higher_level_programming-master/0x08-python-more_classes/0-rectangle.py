#!/usr/bin/python3
"""
Empty class that defines a rectangle
"""


class Rectangle:
    """Empty function"""
    pass
