### Almost a circle
