### Python - Everything is object
