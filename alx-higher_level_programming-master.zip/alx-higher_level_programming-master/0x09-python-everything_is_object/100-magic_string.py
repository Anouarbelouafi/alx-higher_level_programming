#!/usr/bin/python3
def magic_string(lst=[]):
    lst += ["BestSchool"]
    return (", ".join(lst))
